﻿using System.Text;

namespace OHCEB3Nantes
{
    public class Ohce
    {
        public Ohce(IConsole console)
        {
            console.WriteLine("Bonjour");
        }

        public string SaisirChaîne(string input)
        {
            var result = new string(input.Reverse().ToArray());

            var builder = new StringBuilder(result);
            if (result.Equals(input))
            {
                builder.AppendLine();
                builder.Append("Bien dit !");
            }

            return builder.ToString();
        }
    }
}
