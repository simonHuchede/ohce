﻿namespace OHCEB3Nantes
{
    public interface IConsole
    {
        void WriteLine(string text);
        string ReadLine();
    }
}
