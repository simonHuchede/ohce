﻿using OHCEB3Nantes;

var ohce = new Ohce(new SystemConsole());
Console.WriteLine(ohce.SaisirChaîne(Console.ReadLine() ?? ""));